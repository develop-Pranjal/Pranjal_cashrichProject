package com.cashrichproject.Cashrichprojectdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CashrichprojectdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
