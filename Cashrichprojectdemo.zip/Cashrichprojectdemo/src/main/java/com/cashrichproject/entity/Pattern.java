package com.cashrichproject.entity;

public @interface Pattern {

	String regexp();

}
