package com.cashrichproject.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cashrichproject.thirpartyapi.CoinService;

@RestController
@RequestMapping("/coins")
public class CoinController {
    @Autowired
    private CoinService coinService;

    @GetMapping("/data")
    public ResponseEntity<?> getCoinData() {
        return ResponseEntity.ok(((CoinService) coinService).getCoinData());
    }
}