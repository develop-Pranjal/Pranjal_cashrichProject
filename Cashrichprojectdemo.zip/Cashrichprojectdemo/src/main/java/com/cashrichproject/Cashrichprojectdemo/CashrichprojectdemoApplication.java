package com.cashrichproject.Cashrichprojectdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CashrichprojectdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CashrichprojectdemoApplication.class, args);
	}

}
